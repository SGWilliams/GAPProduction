'''
Module to create species-specific metadata for a range table or model raster.
'''